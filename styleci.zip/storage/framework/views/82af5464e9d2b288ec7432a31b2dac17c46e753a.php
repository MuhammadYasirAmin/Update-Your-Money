<h1>Email Verification Mail</h1>

Please verify your email with bellow link:
<a href="<?php echo e(route('user.verify', $token)); ?>">Verify Email</a>
<?php /**PATH C:\Users\pakistan\Documents\GitHub\Update-Your-Money\resources\views/emails/emailVerificationEmail.blade.php ENDPATH**/ ?>