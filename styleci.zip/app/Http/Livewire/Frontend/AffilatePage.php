<?php

namespace App\Http\Livewire\Frontend;

use Livewire\Component;

class AffilatePage extends Component
{
    public function render()
    {
        return view('livewire.frontend.affilate-page')->layout('layouts.main');
    }
}